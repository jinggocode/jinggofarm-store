<?php

/**
*
*/
class Purchase extends MY_Controller
{

	public function __construct()
	{
		parent::__construct();
		$this->_accessable = TRUE;
		$this->load->helper(array('dump', 'utility'));
		$this->load->model(array('product_model', 'article_model','purchase_model','purchase_detail_model'));
	}

	public function detail($id = NULL)
	{
		if ($id != NULL) {
			$purchase = $this->purchase_model->where('kode_pembelian', $id)->get();
			$id 	  = $purchase->id;
		}

		$data['pembelian'] 		= $this->purchase_model->get($id);
		$data['list_pembelian'] = $this->purchase_detail_model->with_product()->where('id_pembelian',$id)->get_all();
		$data['provinsi'] 	= $this->purchase_model->getProvinsi($data['pembelian']->provinsi_id);
		$data['kabupaten']  = $this->purchase_model->getKabupaten($data['pembelian']->kabupaten_id, $data['pembelian']->provinsi_id);

		$this->render('purchase/detail', $data);
	}

	public function check()
	{
		$this->render('purchase/check');
	}

}
