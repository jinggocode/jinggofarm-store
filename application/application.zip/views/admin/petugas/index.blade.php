@layout('_layout/admin/index')

@section('title')Data Petugas@endsection

@section('content')
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Petugas
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="box">
      <div class="box-header with-border">
        <a href="{{site_url('admin/petugas/add')}}" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i> Tambah Data</a>
      </div>
        <div class="box-body">
          <table class="table table-hover table-striped">
                <thead>
                  <th>No.</th>
                  <th>Nama Petugas</th>
                  <th>Nama Percetakan</th>
                  <th>Aksi</th>
                </thead>
                @foreach($tampildata as $row)
                <tr>
                  <td>1</td>
                  <td>{{$row->relasiuser->nama}}</td>
                  <td>{{$row->relasipercetakan->nama}}</td>
                  <td>
                    <a href="{{site_url('admin/petugas/view/'.$row->id)}}" class="btn btn-primary btn-sm"><i class="fa fa-eye"></i> Lihat</a>
                    <a href="{{site_url('admin/petugas/edit/'.$row->id)}}" class="btn btn-warning btn-sm"><i class="fa fa-pencil-square-o"></i> Edit</a>
                    <a href="{{site_url('admin/petugas/delete/'.$row->id)}}" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i> Hapus</a>
                  </td>
                </tr>
                @endforeach
              </table>
        </div>
        <div class="box-footer clearfix">
          {{$pagination}}    
        </div>
      </div>
      <!-- /.box -->

    </section>
    <!-- /.content -->
@endsection