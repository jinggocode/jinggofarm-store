@layout('_layout/pelanggan/index')
@section('title')Daftar Percetakan@endsection
@section('content')
<div class="text-center opaque-overlay bg-light">
    <div class="container py-4">
      <div class="row">
        <div class="col-md-12 text-dark">
          <h1 style="margin-bottom: -4px" class="text-left display-5">Daftar Percetakan <b class="text-primary">Dokumen</b></h1>
          <hr class="text-dark border border-primary mx-0" style="width: 6%"> 
        </div>
      </div>
    </div>
  </div>
  <div class="py-3">
    <div class="container">
      <div class="row">

        <div class="col-md-6 mb-2">
          <div class="card">
            <div class="row no-gutters">
              <div class="col-md-6"> 
                <img class="card-img-top" src="https://pingendo.com/assets/photos/wireframe/photo-1.jpg" width="300" alt="Card image cap">
              </div>
              <div class="col-md-6"> 
                <div class="card-body">
                  <h5 class="card-title"><strong>Kanesa Print</strong></h5>
                  <p class="card-text">
                    <span class="badge badge-primary">Buka</span> <br><br>
                    <i class="fa fa-map-marker text-primary"></i> Kabat, Banyuwangi
                  </p>
                  <a href="{{site_url('percetakan/detail')}}" class="btn btn-primary btn-block btn-sm">Kunjungi</a>
                </div>
              </div>
            </div>
          </div>
        </div> 
        <div class="col-md-6 mb-2">
          <div class="card">
            <div class="row no-gutters">
              <div class="col-md-6"> 
                <img class="card-img-top" src="https://pingendo.com/assets/photos/wireframe/photo-1.jpg" width="300" alt="Card image cap">
              </div>
              <div class="col-md-6"> 
                <div class="card-body">
                  <h5 class="card-title"><strong>Kanesa Print</strong></h5>
                  <p class="card-text">
                    <span class="badge badge-primary">Buka</span> <br><br>
                    <i class="fa fa-map-marker text-primary"></i> Kabat, Banyuwangi
                  </p>
                  <a href="#" class="btn btn-primary btn-block btn-sm">Kunjungi</a>
                </div>
              </div>
            </div>
          </div>
        </div> 
        <div class="col-md-6 mb-2">
          <div class="card">
            <div class="row no-gutters">
              <div class="col-md-6"> 
                <img class="card-img-top" src="https://pingendo.com/assets/photos/wireframe/photo-1.jpg" width="300" alt="Card image cap">
              </div>
              <div class="col-md-6"> 
                <div class="card-body">
                  <h5 class="card-title"><strong>Kanesa Print</strong></h5>
                  <p class="card-text">
                    <span class="badge badge-primary">Buka</span> <br><br>
                    <i class="fa fa-map-marker text-primary"></i> Kabat, Banyuwangi
                  </p>
                  <a href="#" class="btn btn-primary btn-block btn-sm">Kunjungi</a>
                </div>
              </div>
            </div>
          </div>
        </div> 
        <div class="col-md-6 mb-2">
          <div class="card">
            <div class="row no-gutters">
              <div class="col-md-6"> 
                <img class="card-img-top" src="https://pingendo.com/assets/photos/wireframe/photo-1.jpg" width="300" alt="Card image cap">
              </div>
              <div class="col-md-6"> 
                <div class="card-body">
                  <h5 class="card-title"><strong>Kanesa Print</strong></h5>
                  <p class="card-text">
                    <span class="badge badge-primary">Buka</span> <br><br>
                    <i class="fa fa-map-marker text-primary"></i> Kabat, Banyuwangi
                  </p>
                  <a href="#" class="btn btn-primary btn-block btn-sm">Kunjungi</a>
                </div>
              </div>
            </div>
          </div>
        </div> 

      </div>
    </div>
  </div>
@endsection