@layout('_layout/pelanggan/index')
@section('title')Detail Percetakan@endsection
@section('content')
<div class="text-left opaque-overlay bg-light">
    <div class="container py-4">
      <div class="row">
        <div class="col-md-12 text-dark">
          <h1 style="margin-bottom: 5px" class="text-left display-5"><span class="badge badge-primary">BUKA</span> Percetakan Kanesa Print</h1>
          <i class="fa fa-map-marker text-primary"></i> Kabat, Banyuwangi
        </div>
      </div>
    </div>
  </div>

  <div class="py-3">
    <div class="container">
      <div class="row">
        <div class="col-md-3">
          <div class="card">
            <img class="card-img-top" src="https://pingendo.com/assets/photos/wireframe/photo-1.jpg" alt="Card image cap">
            <div class="card-body">
              <h5 class="card-title"><strong>Melayani :</strong></h5>
              <table class="table table-sm" style="font-size: 15px">
                <tr>
                  <td>Print kertas A4</td><td><b>Rp. 500 /lembar</b></td>
                </tr>
                <tr>
                  <td>Cetak Foto</td><td><b>Rp. 500 /lembar</b></td>
                </tr>
                <tr>
                  <td>Cetak Foto</td><td><b>Rp. 500 /lembar</b></td>
                </tr> 
              </table>  
            </div>
          </div>
        </div> 

        <div class="col-md-5">
          <div class="card"> 
            <div class="card-header bg-primary">
              Ayo Mulai Cetak di Kanesa Printing!
            </div>
            <div class="card-body">
              <form>
                <div class="form-group">
                  <label for="exampleInputEmail1">Email address</label>
                  <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
                  <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Password</label>
                  <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
                </div>
                <div class="form-check">
                  <input type="checkbox" class="form-check-input" id="exampleCheck1">
                  <label class="form-check-label" for="exampleCheck1">Check me out</label>
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
              </form>
            </div>  
          </div>
        </div> 

        <div class="col-md-4">  
          <h4 class="mb-3"><b>Percetakan Lainnya</b></h4>
          <div class="card mb-2">
            <div class="row no-gutters">
              <div class="col-md-4"> 
                <img class="card-img-top" src="https://pingendo.com/assets/photos/wireframe/photo-1.jpg" width="100" alt="Card image cap">
              </div>
              <div class="col-md-8"> 
                <div class="card-body">
                  <h5 class="card-title" style="font-size: 16px; margin-bottom: 4px"><strong>Kanesa Print</strong></h5>
                  <p class="card-text" style="font-size: 13px"> 
                    <i class="fa fa-map-marker text-primary"></i> Kabat, Banyuwangi
                  </p> 
                </div>
              </div>
            </div>
          </div>
          <div class="card mb-2">
            <div class="row no-gutters">
              <div class="col-md-4"> 
                <img class="card-img-top" src="https://pingendo.com/assets/photos/wireframe/photo-1.jpg" width="100" alt="Card image cap">
              </div>
              <div class="col-md-8"> 
                <div class="card-body">
                  <h5 class="card-title" style="font-size: 16px; margin-bottom: 4px"><strong>Kanesa Print</strong></h5>
                  <p class="card-text" style="font-size: 13px"> 
                    <i class="fa fa-map-marker text-primary"></i> Kabat, Banyuwangi
                  </p> 
                </div>
              </div>
            </div>
          </div>
        </div>  

      </div>
    </div>
  </div>
@endsection