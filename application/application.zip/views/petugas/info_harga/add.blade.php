@layout('_layout/petugas/index')

@section('title') Data Info Harga@endsection

@section('content')
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Info Harga
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="box">
      <div class="box-header with-border">
      <h3>Tambah Data</h3>
      </div>
        <div class="box-body">
          <div class="row">
            <div class="col-sm-6 col-lg-12">
              <!-- form alert -->
              @if (!empty(validation_errors()))
              <div class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                <h4><strong>Peringatan</strong></h4>
                <p>{{validation_errors()}}</p>
              </div>
              @endif
            </div>
            <!-- end form alert -->
          </div>
          <form class="form-horizontal" action="{{site_url('petugas/info_harga/save')}}" method="post">
          {{$csrf}}
          {{form_hidden('idpercetakan', $petugas->idpercetakan);}}

            <div class="form-group">
              <label for="kategori" class="col-sm-2 control-label">Kategori</label>
              <div class="col-sm-10">
                <select name="kategori" class="form-control" id="iduser">
                  <option value="0">Harga Cetak Dokumen</option>
                  <option value="1">Harga Cetak Foto</option>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label for="nama" class="col-sm-2 control-label">Nama</label>
              <div class="col-sm-10">
                <input type="text" name="nama" class="form-control" value="{{set_value('nama')}}" id="nama" placeholder="Nama">
              </div>
            </div>
            <div class="form-group">
              <label for="harga" class="col-sm-2 control-label">Harga</label>
              <div class="col-sm-10">
                <input type="number" name="harga" class="form-control" value="{{set_value('harga')}}" id="harga" placeholder="Harga">
              </div>
            </div>
            <div class="form-group">
              <label for="satuan" class="col-sm-2 control-label">Satuan</label>
              <div class="col-sm-10">
                <input type="text" name="satuan" class="form-control" value="{{set_value('satuan')}}" id="nama" placeholder="Satuan">
              </div>
            </div>
            <div class="form-group">
              <div class="col-sm-offset-2 col-sm-10">
                <button type="submit" class="btn btn-default">Simpan</button>
              </div>
            </div>
          </form>
        </div>
      </div>
      <!-- /.box -->

    </section>
    <!-- /.content -->
@endsection