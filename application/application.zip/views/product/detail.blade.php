@layout('_layout/front/index')

@section('title'){{$data->kategori->nama.' - '.$data->nama}}@endsection

@section('content')   
<!-- Hero Section-->
<section class="hero hero-page gray-bg padding-small">
  <div class="container">
    <div class="row d-flex">
      <div class="col-lg-9 order-2 order-lg-1">
        <h1>{{$data->nama}}</h1>
      </div>
      <div class="col-lg-3 text-right order-1 order-lg-2">
        <ul class="breadcrumb justify-content-lg-end">
          <li class="breadcrumb-item"><a href="{{site_url()}}">Home</a></li>
          <li class="breadcrumb-item"><a href="{{site_url('product')}}">Produk</a></li>
          <li class="breadcrumb-item active">{{$data->nama}}</li>
        </ul>
      </div>
    </div>
  </div>
</section>
<section class="product-details" style="padding-top: 40px; padding-bottom: 0px">
  <div class="container">
    <div class="row">
      <div class="product-images col-lg-4">
        @if ($data->sisa_stok == 0)
            <div class="ribbon-danger text-uppercase">Stok Habis</div> 
        @else
            <div class="ribbon-primary text-uppercase">Tersedia</div>  
        @endif

        <div data-slider-id="1" class="owl-carousel items-slider owl-drag" style="padding: 0px">
          <div class="item"><img src="{{base_url('uploads/product/'.$data->foto)}}" alt="shirt"></div> 
          <div class="item"><img src="{{base_url('uploads/product/'.$data->foto)}}" alt="shirt"></div> 
        </div>
        <div data-slider-id="1" class="owl-thumbs d-flex align-items-center justify-content-center">
          <button class="owl-thumb-item"><img src="{{base_url('uploads/product/'.$data->foto)}}" alt="shirt"></button> 
          <button class="owl-thumb-item"><img src="{{base_url('uploads/product/'.$data->foto)}}" alt="shirt"></button> 
        </div>
      </div>
      <div class="details col-lg-8">
        <div class="d-flex align-items-center justify-content-between flex-column flex-sm-row mb-4">
          <ul class="price list-inline no-margin">
            <li class="list-inline-item current" style="font-size: 40px">{{money($data->harga_jual)}}</li>
            <li class="list-item">Tersedia <b>{{$data->sisa_stok}}</b> Buah</li> 
          </ul> 
        </div> 

        @if ($data->sisa_stok == 0)

        @else
          <div class="d-flex align-items-center justify-content-between flex-column flex-sm-row mb-4">
            <ul class="price list-inline no-margin">
              <li class="list-inline-item current" style="font-size: 40px">
                <input id="qty" class="form-control col-12" type="number" value="1" min="1" max="{{$data->sisa_stok}}">
              </li>
              <li class="list-inline-item">
                <button data-productid="{{$data->id}}" data-productname="{{$data->nama}}" data-productprice="{{$data->harga_jual}}" data-image="{{base_url('uploads/product/'.$data->foto)}}" class="btn btn-template wide add_cart"> <i class="icon-cart"></i>Beli</button>
              </li> 
            </ul> 
          </div> 
        @endif

        <section class="product-description no-padding">
          <div class="container">
            <ul role="tablist" class="nav nav-tabs">
              <li class="nav-item"><a data-toggle="tab" href="#description" role="tab" class="nav-link active">Deskripsi</a></li>
              <li class="nav-item"><a data-toggle="tab" href="#additional-information" role="tab" class="nav-link">Testimoni Pelanggan</a></li>
            </ul>
            <div class="tab-content">
              <div id="description" role="tabpanel" class="tab-pane active" style="text-align: justify;">
                {{$data->deskripsi}}
              </div>
              <div id="additional-information" role="tabpanel" class="tab-pane">
                <table class="table">
                  <tr>
                    <td style="width: 20%"><b>Rahmat Rdn.</b></td>
                    <td>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eligendi facilis velit, quidem numquam! Consectetur voluptatum quasi sapiente reiciendis, optio soluta aliquam sequi omnis adipisci labore, beatae, qui reprehenderit. Neque, cum.</td>
                  </tr>
                </table> 
              </div>
            </div>
          </div> 
        </section>

      </div>
    </div>
  </div>
</section>
<section class="product-description no-padding"> 
  <div class="container-fluid">
    <div class="share-product gray-bg d-flex align-items-center justify-content-center flex-column flex-md-row"><strong class="text-uppercase">Ayo Bagikan Produk ini di</strong>
      <ul class="list-inline text-center">
        <li class="list-inline-item"><a href="#" target="_blank" title="twitter"><i class="fa fa-twitter"></i></a></li>
        <li class="list-inline-item"><a href="#" target="_blank" title="facebook"><i class="fa fa-facebook"></i></a></li>
        <li class="list-inline-item"><a href="#" target="_blank" title="instagram"><i class="fa fa-instagram"></i></a></li>
        <li class="list-inline-item"><a href="#" target="_blank" title="pinterest"><i class="fa fa-pinterest"></i></a></li>
        <li class="list-inline-item"><a href="#" target="_blank" title="vimeo"><i class="fa fa-vimeo"></i></a></li>
      </ul>
    </div>
  </div>
</section>
<section class="related-products">
  <div class="container">
    <header class="text-center">
      <h2><small>Produk Lain dari</small>Kategori Makanan</h2>
    </header>
    <div class="row">
      <!-- item-->
      <div class="item col-lg-3">
        <div class="product is-gray">
          <div class="image d-flex align-items-center justify-content-center"><img src="https://d19m59y37dris4.cloudfront.net/hub/1-3-0/img/hoodie-woman-1.png" alt="..." class="img-fluid">
            <div class="hover-overlay d-flex align-items-center justify-content-center">
              <div class="CTA d-flex align-items-center justify-content-center"><a href="#" class="add-to-cart"><i class="fa fa-shopping-cart"></i></a><a href="detail.html" class="visit-product active"><i class="icon-search"></i>View</a><a href="#" data-toggle="modal" data-target="#exampleModal" class="quick-view"><i class="fa fa-arrows-alt"></i></a></div>
            </div>
          </div>
          <div class="title"><a href="#">
              <h3 class="h6 text-uppercase no-margin-bottom">Elegant Gray</h3></a><span class="price">$40.00</span></div>
        </div>
      </div> 
    </div>
  </div>
</section>
@endsection 

@section('cart')
<div class="cart dropdown show">
  <a id="cartdetails" href="https://example.com" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle"><i class="icon-cart"></i>
  <div class="cart-no" id="cart-count-row"></div>
  </a>
  <a href="{{site_url('cart')}}" class="text-primary view-cart">Keranjang Belanja</a>
  <div aria-labelledby="cartdetails" class="dropdown-menu" id="cart-item">
    
  </div>
</div>
@endsection

@section('script')
<script type="text/javascript">
    $(document).ready(function(){ 
      // this bit needs to be loaded on every page where an ajax POST may happen
      $.ajaxSetup({
          data: {
              csrf_test_name: $.cookie('csrf_cookie_name')
          }
      });
        $('.add_cart').click(function(){
            var product_id    = $(this).data("productid"); 
            var product_name  = $(this).data("productname");
            var product_price = $(this).data("productprice");
            var image         = $(this).data("image");
            var quantity      = $("#qty").val();
            var sisa_stok     = <?php echo $data->sisa_stok; ?>;

            if (parseInt(sisa_stok) < parseInt(quantity)) {
              alert('Kesalahan memasukkan jumlah pembelian!');
            } else {  
              $.ajax({
                  url : "<?php echo site_url('product/add_to_cart');?>",
                  method : "POST", 
                  data : {product_id: product_id, product_name: product_name, product_price: product_price, quantity: quantity, image: image},
                  success: function(data){
                      $('#cart-item').html(data);  
                      $('#cart-count-row').load("<?php echo site_url('product/count_cart');?>");  
                      sweet("Berhasil", "Ditambahkan ke dalam Cart", "success");
                  }
              });
            } 

        });
         
        $('#cart-item').load("<?php echo site_url('product/load_cart');?>");
        $('#cart-count-row').load("<?php echo site_url('product/count_cart');?>");
 
        $(document).on('click','.delete_cart',function(){ 
            var r = confirm("Apakah anda Yakin?");
            if (r == true) {
              var row_id=$(this).attr("id"); 
              $.ajax({
                  url : "<?php echo site_url('product/delete_cart');?>",
                  method : "POST",
                  data : {row_id : row_id},  
                  success: function(data){
                      $('#cart-item').html(data);
                      $('#cart-count-row').load("<?php echo site_url('product/count_cart');?>");
                      sweet("Berhasil", "Dihapus dari Keranjang", "warning");
                  } 
              });
            } else { 
            }  

        });

        function sweet(tipe, pesan, icon){
          swal(tipe, pesan, icon);
        } 
        window.onload = sweet;
    });
</script>
@endsection