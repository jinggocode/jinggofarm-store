@layout('_layout/front/index')

@section('title')Cek Pembelian@endsection

@section('content')
<section class="hero hero-page gray-bg padding-small">
  <div class="container">
    <div class="row d-flex">
      <div class="col-lg-12 order-2 order-lg-1">
        <h1>{{$pembelian->kode_pembelian}}</h1>
        <p class="lead">
          Pembelian {{$pembelian->kode_pembelian}} yang dilakukan pada tanggal <strong>{{dateFormatBulan(3, $pembelian->created_at)}}</strong> <br>
          
            {{($pembelian->status == '1')?'<span class="badge badge-warning">Validasi Transfer</span>':''}}
            {{($pembelian->status == '2')?'<span class="badge badge-primary">Persiapan Kirim</span>':''}}
            {{($pembelian->status == '3')?'<span class="badge badge-success">Pengiriman</span> No. Resi <b>'.$pembelian->no_resi.'</b>':''}}
            {{($pembelian->status == '4')?'<span class="badge badge-danger">Transfer Tidak Valid</span>':''}}
        </p>
        <p class="text-muted">Jika anda memiliki pertanyaan silahkan menghubungi admin di 082246512362</p>
      </div>
    </div>
  </div>
</section>
<section class="padding-small">
  <div class="container">
    <div class="row">

      <div class="col-lg-12 col-xl-12 pl-lg-3">
        <div class="basket basket-customer-order">
          <div class="basket-holder">
            <div class="basket-header">
              <div class="row">
                <div class="col-6">Produk</div>
                <div class="col-2">Harga</div>
                <div class="col-2">Kuantitas</div>
                <div class="col-2 text-right">Total</div>
              </div>
            </div>
            <div class="basket-body">
              <!-- Product-->
              @foreach ($list_pembelian as $value)
              <div class="item">
                <div class="row d-flex align-items-center">
                  <div class="col-6">
                    <div class="d-flex align-items-center"><img src="{{base_url('uploads/product/'.$value->product->foto)}}" class="img-fluid">
                      <div class="title">
                        <a><h6>{{$value->product->nama}}</h6></a>
                      </div>
                    </div>
                  </div>
                  <div class="col-2"><span>{{money($value->product->harga_jual)}}</span></div>
                  <div class="col-2">{{$value->qty}}</div>
                  <div class="col-2 text-right"><span>{{money($value->subtotal)}}</span></div>
                </div>
              </div>
              @endforeach

            </div>
            <div class="basket-footer">
              <div class="item">
                <div class="row">
                  <div class="offset-md-6 col-4"> <strong>Pembelian subtotal</strong></div>
                  <div class="col-2 text-right"><strong>{{money($pembelian->jumlah_bayar)}}</strong></div>
                </div>
              </div>
              <div class="item">
                <div class="row">
                  <div class="offset-md-6 col-4"> <strong>Ongkos Kirim</strong></div>
                  <div class="col-2 text-right"><strong>{{money($pembelian->biaya_kirim)}}</strong></div>
                </div>
              </div>
              <div class="item">
                <div class="row">
                  <div class="offset-md-6 col-4"> <strong>Total</strong></div>
                  <div class="col-2 text-right"><strong>{{money($pembelian->jumlah_bayar + $pembelian->biaya_kirim)}}</strong></div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="row addresses">
          <div class="col-sm-12">
            <div class="block-header">
              <h6 class="text-uppercase">Alamat Pengiriman</h6>
            </div>
            <div class="block-body">
              <p>{{$kabupaten['city_name']}}, {{$provinsi}} <br>{{$pembelian->detail_alamat}} <br>{{$kabupaten['postal_code']}}</p>
            </div>
          </div>
        </div>
        <!-- /.addresses                           -->
      </div>
    </div>
  </div>
</section>
@endsection

@section('cart')
@endsection

@section('script')
<script type="text/javascript">
    $(document).ready(function(){
      // this bit needs to be loaded on every page where an ajax POST may happen
      $.ajaxSetup({
          data: {
              csrf_test_name: $.cookie('csrf_cookie_name')
          }
      });

        $('#cart-item').load("<?php echo site_url('product/load_cart');?>");
        $('#cart-count-row').load("<?php echo site_url('product/count_cart');?>");

        $(document).on('click','.delete_cart',function(){
            var r = confirm("Apakah anda Yakin?");
            if (r == true) {
              var row_id=$(this).attr("id");
              $.ajax({
                  url : "<?php echo site_url('product/delete_cart');?>",
                  method : "POST",
                  data : {row_id : row_id},
                  success: function(data){
                      $('#cart-item').html(data);
                      $('#cart-count-row').load("<?php echo site_url('product/count_cart');?>");
                      sweet("Berhasil", "Dihapus dari Keranjang", "warning");
                  }
              });
            } else {
            }

        });

        function sweet(tipe, pesan, icon){
          swal(tipe, pesan, icon);
        }
        window.onload = sweet;
    });
</script>
@endsection
