@layout('_layout/admin/index')
@section('title')Selamat Datang Admin @endsection
@section('content')   

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="box"> 
        <div class="box-body"> 
          <div class="row" align="center">
            <div class="col-md-12">
              <h1>Selamat Datang Admin</h1>
              <p>Anda Masuk sebagai Administrator</p>
            </div>
          </div>
        </div> 
      </div>
      <!-- /.box -->

    </section>
    <!-- /.content -->

@endsection